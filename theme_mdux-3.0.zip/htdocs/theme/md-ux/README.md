# theme-dolibarr-md-ux
Vous pouvez fabriquer un package en utilisant le script build/makepack-dolibarrtheme.pl ou en copiant les fichiers dans un dossier /htdocs/theme/md-ux/

Forum FR : https://www.dolibarr.fr/forum/511-creation-dun-nouveau-module/61688-theme-md-ux

Compatible Dolibarr 14
